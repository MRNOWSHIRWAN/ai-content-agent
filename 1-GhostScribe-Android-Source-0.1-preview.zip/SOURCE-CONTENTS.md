# Source preview

Android Java/WebView source, gateway modules, Python CLI, local tests and setup docs. No signed APK, key or pairing token included. Gateway module config contains only a placeholder database ID. Extract and read docs/SETUP.md and docs/TESTS.md. This is a development preview, not a phone-tested release.
