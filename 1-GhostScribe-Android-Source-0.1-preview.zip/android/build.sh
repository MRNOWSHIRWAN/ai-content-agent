#!/usr/bin/env bash
set -euo pipefail
# Required: JDK 17, Android SDK platform 35 and build-tools 35.0.0.
: "${JAVA_HOME:?Set JAVA_HOME to JDK 17}" "${ANDROID_JAR:?Set ANDROID_JAR to platform android.jar}" "${BUILD_TOOLS:?Set BUILD_TOOLS to SDK build-tools directory}"
export PATH="$JAVA_HOME/bin:$PATH"
cd "$(dirname "$0")"
mkdir -p build/classes build/dex
"$BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml -A assets -o build/base.apk
javac -source 11 -target 11 -classpath "$ANDROID_JAR" -d build/classes src/com/ghostscribe/assistant/*.java
"$BUILD_TOOLS/d8" --lib "$ANDROID_JAR" --min-api 26 --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -j ../unsigned.apk classes.dex)
"$BUILD_TOOLS/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
if [[ -n "${SIGNING_KEYSTORE:-}" ]]; then
 "$BUILD_TOOLS/apksigner" sign --ks "$SIGNING_KEYSTORE" --out build/ghostscribe-preview.apk build/aligned.apk
 "$BUILD_TOOLS/apksigner" verify build/ghostscribe-preview.apk
else
 echo 'Unsigned APK created. Supply your own stable signing keystore to install.'
fi
