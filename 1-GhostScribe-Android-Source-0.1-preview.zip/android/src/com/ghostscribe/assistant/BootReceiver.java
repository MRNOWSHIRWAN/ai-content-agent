package com.ghostscribe.assistant;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){ReminderStore.reschedule(c);}}
