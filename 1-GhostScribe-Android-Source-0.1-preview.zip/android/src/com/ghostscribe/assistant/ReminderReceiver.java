package com.ghostscribe.assistant;
import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.os.Build;import org.json.*;
public class ReminderReceiver extends android.content.BroadcastReceiver {
 public void onReceive(Context c,Intent intent){int id=intent.getIntExtra("id",-1);JSONArray a=ReminderStore.read(c);for(int i=0;i<a.length();i++)try{JSONObject r=a.getJSONObject(i);if(r.getInt("id")!=id||r.optBoolean("done")||r.optBoolean("fired"))continue;
  if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)return;
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("reminders","Plan reminders",NotificationManager.IMPORTANCE_HIGH));
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  nm.notify(id,new Notification.Builder(c,"reminders").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("GhostScribe reminder").setContentText(r.getString("title")).setContentIntent(open).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).build());r.put("fired",true);ReminderStore.write(c,a);
 }catch(Exception ignored){}}
}
