package com.ghostscribe.assistant;
import android.app.*;import android.content.*;import android.os.Build;import org.json.*;
public class ReminderStore {
 static JSONArray read(Context c) {try{return new JSONArray(c.getSharedPreferences("local",0).getString("reminders","[]"));}catch(Exception e){return new JSONArray();}}
 static void write(Context c,JSONArray a){c.getSharedPreferences("local",0).edit().putString("reminders",a.toString()).commit();}
 static PendingIntent pending(Context c,int id){Intent i=new Intent(c,ReminderReceiver.class);i.putExtra("id",id);return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static boolean schedule(Context c,JSONObject r)throws Exception {AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);long time=r.getLong("time");if(time<=System.currentTimeMillis()||r.optBoolean("done")||r.optBoolean("fired"))return false;
  if(Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms()){am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending(c,r.getInt("id")));return true;}am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending(c,r.getInt("id")));return false;}
 static void reschedule(Context c){JSONArray a=read(c);for(int i=0;i<a.length();i++)try{schedule(c,a.getJSONObject(i));}catch(Exception ignored){}}
 static void cancel(Context c,int id){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pending(c,id));}
}
