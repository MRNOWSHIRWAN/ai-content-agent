export function validateChat(b){
 if(!b||Object.keys(b).sort().join(',')!=='consent,language,message'||b.consent!==true||!['english','hinglish'].includes(b.language)||typeof b.message!=='string'||!b.message.trim()||b.message.length>1200)throw new Error('Consent, language and a non-personal question (max 1200 characters) required');
 return {message:b.message.trim(),language:b.language};
}
export function chatPrompt(b){let v=validateChat(b);return `Help with general study, generic timetable templates and public research questions in ${v.language}. Do not pretend to read private notes, calendars or profiles. You have no browser or verified current sources in this chat mode. For current facts, say that source research is needed rather than inventing links. If user shares personal/confidential information, advise using local notes and do not ask for more. No external actions are possible. User's explicitly submitted online question follows:\n${v.message}`;}
