import {chatPrompt} from './chat.mjs';
import {RESEARCH,validateResearch,stripHtml,researchPrompt} from './research-catalog.mjs';
import {studyPrompt} from './catalog.mjs';
const SOURCE = 'https://www.bleepingcomputer.com/feed/';
const MODEL='gemini-2.5-flash-lite';
const json=(obj,status=200)=>new Response(JSON.stringify(obj),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
export default {
 async fetch(request, env) {
  if(request.method !== 'POST') return json({error:'POST only'},405);
  if(!env.DEVICE_TOKEN || request.headers.get('Authorization') !== `Bearer ${env.DEVICE_TOKEN}`) return json({error:'Pair this device first'},401);
  if(Number(request.headers.get('Content-Length')||0)>2048) return json({error:'Request too large'},413);
  let raw=await request.text();if(raw.length>2048)return json({error:'Request too large'},413);
  let body;try{body=JSON.parse(raw);}catch{return json({error:'Invalid JSON'},400);}
  const path=new URL(request.url).pathname;
  if(path==='/study' || path==='/deep-research' || path==='/chat') {
   let prompt;let sources=[];
   try{if(path==='/study')prompt=studyPrompt(body);else if(path==='/chat')prompt=chatPrompt(body);else validateResearch(body);}catch(e){return json({error:e.message},400);}
   if(!env.GEMINI_API_KEY)return json({error:'AI not set up. Local notes and reminders still work.'},503);
   if(!env.QUOTA)return json({error:'Daily quota storage not configured'},503);
   const day=new Date().toISOString().slice(0,10);
   // Atomic per-owner daily budget. Fail closed; no unlimited fallback.
   await env.QUOTA.prepare('INSERT OR IGNORE INTO usage(day,count) VALUES(?,0)').bind(day).run();
   const out=await env.QUOTA.prepare('UPDATE usage SET count=count+1 WHERE day=? AND count<30 RETURNING count').bind(day).first();
   if(!out)return json({error:'30 lesson requests used today. Try again after 00:00 UTC. Local tools still work.'},429);
   if(path==='/deep-research') {
    for (const src of RESEARCH[body.topic].sources) {
     try {
      // No redirects: an external page cannot choose a new retrieval destination.
      const response=await fetch(src.url,{redirect:'manual',signal:AbortSignal.timeout(12000)});
      if(!response.ok || !response.headers.get('content-type')?.includes('text/html'))continue;
      const reader=response.body.getReader();let text='',bytes=0;const decoder=new TextDecoder();
      while(bytes<60000){const part=await reader.read();if(part.done)break;bytes+=part.value.length;text+=decoder.decode(part.value,{stream:true});}await reader.cancel();
      const excerpt=stripHtml(text).slice(0,8000);
      if(excerpt.length<300 || /verify you are human|access denied|checking your browser/i.test(excerpt.slice(0,1000)))continue;
      sources.push({...src,excerpt});
     }catch{}
    }
    if(!sources.length)return json({error:'No readable primary source found. No unsourced report generated.'},503);
    prompt=researchPrompt(body.topic,body.language,sources);
   }
   const upstream=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${env.GEMINI_MODEL||MODEL}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.3,maxOutputTokens:1800}}),signal:AbortSignal.timeout(30000)}).catch(()=>null);
   if(!upstream || !upstream.ok)return json({error:'AI is unavailable or free quota is exhausted. No paid fallback.',upstream_status:upstream?.status||'network-timeout'},503);
   const data=await upstream.json(); const text=data.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('');
   return text?json({text,mode:path==='/chat'?'user-submitted-online-chat':'public-only',model:MODEL,sources:sources.map(({title,url})=>({title,url})),notice:path==='/chat'?'Online chat: your typed question was sent to free Gemini. Not live sourced research.':path==='/deep-research'?'Curated public-source synthesis. Limited excerpts; check linked originals.':'General study lesson'}):json({error:'No lesson returned'},503);
  }
  if(path==='/research') {
   if(!body||Object.keys(body).length)return json({error:'This endpoint accepts no user text'},400);
   const resp=await fetch(SOURCE,{signal:AbortSignal.timeout(15000)}).catch(()=>null);
   if(!resp||!resp.ok)return json({error:'Public feed unavailable'},503);
   const xml=(await resp.text()).slice(0,150000);
   // Public RSS digest, not a claim that articles have been fact-checked.
   const items=[...xml.matchAll(/<item[\s>]([\s\S]*?)<\/item>/g)].slice(0,5).map(m=>{
    const read=t=>(m[1].match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)<\\/${t}>`))?.[1]||'').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").slice(0,500);
    return {title:read('title'),url:read('link'),date:read('pubDate')};
   }).filter(x=>/^https:\/\/www\.bleepingcomputer\.com\//.test(x.url));
   return json({items,source:SOURCE,notice:'Public RSS headlines. Open the linked article before relying on a claim.'});
  }
  return json({error:'Not found'},404);
 }
};
