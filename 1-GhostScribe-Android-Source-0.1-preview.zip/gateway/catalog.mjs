export const TOPICS = Object.freeze({python:'Python basics',linux:'Linux basics',networking:'Computer networking basics',soc:'Security operations centre fundamentals',ai:'Artificial intelligence fundamentals',math:'Discrete mathematics basics'});
export const ACTIONS = Object.freeze({explain:'Explain with a worked example',quiz:'Write five questions, followed by answers',plan:'Give a seven-day generic learning plan'});
export const LANGUAGES = Object.freeze({english:'English',hinglish:'Simple Hinglish'});
export function validateStudy(body) {
 if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('Invalid request');
 const keys=Object.keys(body).sort().join(',');
 if(keys !== 'action,language,topic') throw new Error('Private text and extra fields are not accepted');
 if(!Object.hasOwn(TOPICS,body.topic)||!Object.hasOwn(ACTIONS,body.action)||!Object.hasOwn(LANGUAGES,body.language)) throw new Error('Choose a listed topic, action and language');
 return {topic:body.topic,action:body.action,language:body.language};
}
export function studyPrompt(body){const b=validateStudy(body);return `${ACTIONS[b.action]} about ${TOPICS[b.topic]}. Use ${LANGUAGES[b.language]}. This is a generic public lesson. Do not ask for personal information. Clearly distinguish examples from facts. For cybersecurity, use defensive learning examples only.`;}
