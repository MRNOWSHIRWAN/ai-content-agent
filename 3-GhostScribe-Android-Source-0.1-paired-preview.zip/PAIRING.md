# Private phone pairing

The APK contains no secrets. Obtain your own private pairing JSON from your owner-only storage. Download it, open Setup > Import private pairing file, select the JSON and confirm the HTTPS host. Delete the downloaded JSON. Never share it, include it in source, or send it in chat. Pairing only changes gateway connection credentials, not local notes.
